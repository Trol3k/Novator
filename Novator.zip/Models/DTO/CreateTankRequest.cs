﻿namespace Novator.Models.DTO
{
    public class CreateTankRequest
    {
        public double Capacity { get; set; }
    }
}
