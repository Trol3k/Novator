﻿namespace Novator.Models.DTO
{
    public class CreatePassengerRequest
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }
}
