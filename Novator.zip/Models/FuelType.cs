﻿namespace Novator.Models
{
    public enum FuelType
    {
        Diesel,
        HeavyFuel
    }
}
